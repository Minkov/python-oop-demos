from project.cat import Cat
from project.dog import Dog

cat = Cat()
dog = Dog()

print(cat.eat())
print(cat.meow())

print(dog.eat())
print(dog.bark())
