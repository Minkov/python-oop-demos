from project.sports_car import SportsCar

sc = SportsCar()

print(sc.move())  # From `Vehicle`
print(sc.drive())  # From `Car`
print(sc.race())  # from `SportsCar`
