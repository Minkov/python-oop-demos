from project.cat import Cat
from project.dog import Dog

d = Dog()
c = Cat()

print(d.eat())
print(d.bark())
print(c.eat())
print(c.meow())
