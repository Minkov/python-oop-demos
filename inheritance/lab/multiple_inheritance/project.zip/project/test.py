from project.teacher import Teacher

t = Teacher()

print(t.teach())
print(t.get_fired())
print(t.sleep())
