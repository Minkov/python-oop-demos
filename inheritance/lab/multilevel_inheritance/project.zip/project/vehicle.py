class Vehicle:
    def move(self):
        return 'moving...'
