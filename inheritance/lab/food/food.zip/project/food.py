class Food:
    def __init__(self, expiration_date):
        self.expiration_date = expiration_date
